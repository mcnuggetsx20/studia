public interface PizzaStrategy{
    public void orderPizza(Pizza pizza);
}
